/**
 * 
 */
package celization.civilians;

/**
 * @author mjafar
 * 
 */
public enum WorkerState {
	Free, Building, MiningStone, MiningGold, WoodCamp, Farming
}
