/**
 * 
 */
package celization.civilians.workeractions;

import celization.CElization;
import celization.Coordinates;
import celization.exceptions.IllegalDuplicateException;
import celization.exceptions.InsufficientResearchesException;
import celization.exceptions.InsufficientResourcesException;

/**
 * @author mjafar
 * 
 */
public final class Build extends WorkerActions {

	private String UID;
	private Coordinates location;
	private String buildingType;

	/**
	 * 
	 */
	public Build(String id, Coordinates l, String type) {
		UID = id;
		location = l;
		buildingType = type;

	}

	public String getWorkplace() {
		return UID;
	}

	public void Do(CElization game) throws IllegalArgumentException,
			InsufficientResourcesException, InsufficientResearchesException,
			IllegalDuplicateException {
		game.gameState.events.add(String.format("construction started %s", game
				.makeNewBuilding(String.format("worker:%s", UID), location,
						buildingType)));
	}

}
