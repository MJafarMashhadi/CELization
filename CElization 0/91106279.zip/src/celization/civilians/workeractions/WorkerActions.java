package celization.civilians.workeractions;

public abstract class WorkerActions {

}
