/**
 * 
 */
package celization.civilians.workeractions;

import celization.Coordinates;

/**
 * @author mjafar
 * 
 */
public final class Move extends WorkerActions {

	private Coordinates destination;

	/**
	 * Constructor: set destination
	 */
	public Move(Coordinates d) {
		destination = new Coordinates(0, 0);
		setDestination(d);
	}

	/**
	 * get destination
	 * 
	 * @return
	 */
	public Coordinates getDestination() {
		return destination;
	}

	/**
	 * Update destination
	 * 
	 * @param new destination
	 */
	public void setDestination(Coordinates d) {
		destination.row = d.row;
		destination.col = d.col;
	}

}
