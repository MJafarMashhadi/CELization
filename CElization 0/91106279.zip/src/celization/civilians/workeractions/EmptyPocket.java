/**
 * 
 */
package celization.civilians.workeractions;

/**
 * @author mjafar
 * 
 */
public final class EmptyPocket extends WorkerActions {
	/**
	 * 
	 */
	public EmptyPocket() {

	}

}
