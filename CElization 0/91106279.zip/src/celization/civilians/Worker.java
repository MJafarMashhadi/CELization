/**
 * 
 */
package celization.civilians;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import celization.Coordinates;
import celization.GameParameters;
import celization.NaturalResources;
import celization.PathFinder;
import celization.needsGameInstance;
import celization.buildings.Building;
import celization.civilians.workeractions.Build;
import celization.civilians.workeractions.EmptyPocket;
import celization.civilians.workeractions.Move;
import celization.civilians.workeractions.WorkerActions;
import celization.exceptions.IllegalDuplicateException;
import celization.exceptions.InsufficientResearchesException;
import celization.exceptions.InsufficientResourcesException;

/**
 * @author mjafar
 * 
 */
public final class Worker extends Civilian implements needsGameInstance {
	private Map<String, Experience> experience = new HashMap<String, Experience>();
	private NaturalResources carryingResources;

	public WorkerState workState;
	private String workPlace;

	private LinkedList<WorkerActions> actionsQueue = new LinkedList<WorkerActions>();

	Coordinates nextPos;

	public Worker(String name) {
		super(name);

		workState = WorkerState.Free;

		/** each worker consumes 2 units of food */
		foodConsumption = GameParameters.workerFoodConsumption;

		this.name = name;

		experience.put(GameParameters.ExpAgriculture, new Experience());
		experience.put(GameParameters.ExpGoldMining, new Experience());
		experience.put(GameParameters.ExpStoneMining, new Experience());
		experience.put(GameParameters.ExpCarpentary, new Experience());
		experience.put(GameParameters.ExpCivilEng, new Experience());

		carryingResources = new NaturalResources();

		creationTime = GameParameters.workerETA;
	}

	public void addAction(WorkerActions a) {
		actionsQueue.add(a);
		if (a instanceof Move) {
			updateNextPos();
		}
	}

	public void extract(String materialType, double amount) {
		/** cannot extract */
		// FIXME:comatible with new definitions
		if (!hasCapacity(amount)) {
			return;
		}
		/** gain experience */
		experience.get(materialType).excercise();
		/** put materials in pocket */
		if (materialType.equals(GameParameters.ExpAgriculture)) {
			carryingResources.numberOfFood += amount;
		} else if (materialType.equals(GameParameters.ExpGoldMining)) {
			carryingResources.numberOfGolds += amount;
		} else if (materialType.equals(GameParameters.ExpStoneMining)) {
			carryingResources.numberOfStones += amount;
		} else if (materialType.equals(GameParameters.ExpCarpentary)) {
			carryingResources.numberOfWoods += amount;
		}
		/** pocket will be full in next turn */
		if (!hasCapacity(amount)) {
			actionsQueue.add(new Move(PathFinder.nearestStorage(position,
					(Building[]) gameInstance.gameState.buildings.values()
							.toArray())));
			actionsQueue.add(new EmptyPocket());
			actionsQueue.add(new Move(position));
		}
	}

	public boolean hasCapacity(double amount) {
		return amount + carryingResources.sum() <= GameParameters.workerPocketCapacity;
	}

	public double getExperience(String type) {
		return experience.get(type).amountOfExperience;
	}

	public void excersize(String type) {
		experience.get(type).excercise();
	}

	public NaturalResources getInventory() {
		return carryingResources;
	}

	public String getOccupationForJudge(String myID) {
		// FIXME: i think it's totally wrong!
		switch (workState) {
		case Building:
			return String.format("constructing %s", "something", workPlace);

		case MiningStone:
			return String.format("working at %s %s", "stone mine", workPlace);

		case MiningGold:
			return String.format("working at %s %s", "gold mine", workPlace);

		case WoodCamp:
			return String.format("working at %s %s", "wood camp", workPlace);

		case Farming:
			return String.format("working at %s %s", "farm", workPlace);

		case Free:
			return "idle";
		}

		return null;
	}

	private void stepMove() {
		if (moving()) {
			/** go on one step */
			setPosition(nextPos);
			/** unlock visited cells */
			int diff = (GameParameters.workerUnlockArea.row - 1) / 2;
			gameInstance.gameState.gameMap.unlockCells(new Coordinates(
					position.col - diff, position.row - diff),
					GameParameters.workerUnlockArea);
			if (position.equals(((Move) actionsQueue.getFirst())
					.getDestination())) {
				goOnInQueue();
			} else {
				updateNextPos();
			}
		}
	}

	public void move(Coordinates d) throws IllegalArgumentException {
		if (d.row < 0 || d.row >= GameParameters.gameMapSize.row || d.col < 0
				|| d.col >= GameParameters.gameMapSize.col) {
			throw new IllegalArgumentException();
		}

		if (moving()) {
			// update destination
			((Move) actionsQueue.getFirst()).setDestination(d);
		} else {
			actionsQueue.add(new Move(d));
		}
		updateNextPos();
	}

	private void updateNextPos() {
		boolean haveMoveInQueue = false;
		String whereToGo = new String();
		for (WorkerActions a : actionsQueue) {
			if (a instanceof Move) {
				whereToGo = PathFinder.findPath(position,
						((Move) a).getDestination());
				haveMoveInQueue = true;
			}
		}
		if (!haveMoveInQueue) {
			return;
		}
		nextPos = position.clone();
		if (whereToGo.equals("up")) {
			nextPos.row--;
		} else if (whereToGo.equals("down")) {
			nextPos.row++;
		} else if (whereToGo.equals("right")) {
			nextPos.col++;
		} else if (whereToGo.equals("left")) {
			nextPos.col--;
		}
	}

	private boolean moving() {
		if (actionsQueue.size() == 0) {
			return false;
		}
		return actionsQueue.getFirst() instanceof Move;
	}

	private void goOnInQueue() {
		if (actionsQueue.size() > 0) {
			actionsQueue.removeFirst();
		}
	}

	public void step() {
		if (actionsQueue.size() == 0) {
			return;
		}
		if (moving()) {
			stepMove();
		} else if (actionsQueue.getFirst() instanceof Build) {

			try {
				((Build) actionsQueue.getFirst()).Do(gameInstance);
			} catch (IllegalArgumentException e) {
				// won't happen
			} catch (InsufficientResourcesException e) {
				System.err.println("ran out of resources");
			} catch (InsufficientResearchesException e) {
				// won't happen
			} catch (IllegalDuplicateException e) {
				// won't happen
			}
			goOnInQueue();
		} else if (actionsQueue.getFirst() instanceof EmptyPocket) {
			gameInstance.gameState.storedResources.add(carryingResources);
			carryingResources.clear();
			goOnInQueue();
			step();
		}
	}

	@Override
	public String getTypeString() {
		return "worker";
	}
}