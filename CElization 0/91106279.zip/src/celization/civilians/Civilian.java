/**
 * 
 */
package celization.civilians;

import celization.CElization;
import celization.Coordinates;
import celization.needsGameInstance;

/**
 * @author mjafar
 * 
 */
public abstract class Civilian implements needsGameInstance {
	protected String name;
	protected boolean alive;
	protected int foodConsumption;
	protected Coordinates position;
	protected CElization gameInstance;

	protected int creationTime;
	protected int creationPhase;

	public Civilian(String name) {
		alive = true;
		position = new Coordinates(0, 0);
		this.name = name;
		creationPhase = 0;
	}

	public void die() {
		alive = false;
	}

	public boolean stillAlive() {
		return alive;
	}

	public Coordinates getPos() {
		return position;
	}

	public void setPosition(Coordinates newPosition) {
		position.row = newPosition.row;
		position.col = newPosition.col;
	}

	public String getName() {
		return name;
	}

	public int getFoodConsumption() {
		return foodConsumption;
	}

	public abstract String getTypeString();

	public void injectGameInstance(CElization g) {
		gameInstance = g;
	}

	public void growUp() {
		if (creationPhase < creationTime) {
			creationPhase++;
		}
	}

	public boolean isMature() {
		return creationPhase >= creationTime;
	}
}
