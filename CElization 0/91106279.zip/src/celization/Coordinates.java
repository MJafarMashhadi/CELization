/**
 * 
 */
package celization;

/**
 * @author mjafar
 * 
 */
public class Coordinates {
	public int col;
	public int row;

	public Coordinates(int col, int row) {
		this.col = col;
		this.row = row;
	}

	@Override
	public String toString() {
		return String.format("(%3d, %3d)", col, row);
	}

	public boolean equals(Coordinates c) {
		return ((c.row == row) && (c.col == col));
	}

	public Coordinates clone() {
		return new Coordinates(col, row);
	}
}
