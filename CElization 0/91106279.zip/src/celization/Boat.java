/**
 * 
 */
package celization;

import java.util.LinkedList;

import celization.mapgeneration.BlockType;

/**
 * @author mjafar
 * 
 */
public final class Boat implements needsGameInstance {

	/**
	 * 
	 */
	private Coordinates position;
	public String portUniqueId;

	private CElization gameInstance;

	private int requiredBuildingTime;
	private int buildingPhase;

	public Boat() {
		requiredBuildingTime = GameParameters.boatETA;
		buildingPhase = 0;
	}

	public void addToPort(String puid) {
		portUniqueId = puid;
		position = gameInstance.getBuildingByUID(portUniqueId).position;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * celization.needsGameInstance#injectGameInstance(celization.CElization)
	 */
	@Override
	public void injectGameInstance(CElization game) {
		gameInstance = game;
	}

	public void wander() {
		LinkedList<Integer> directions = new LinkedList<Integer>();
		/***************
		 * \ | / * 8 1 2 * --7 . 3--* 6 5 4 * / | \ *
		 ***************/
		directions.add(1);
		directions.add(2);
		directions.add(3);
		directions.add(4);
		directions.add(5);
		directions.add(6);
		directions.add(7);
		directions.add(8);
		int c, r;
		for (int i = 0; i < directions.size(); i++) {
			if (i == 1 || i == 5) {
				c = position.col;
			} else if (2 <= i && i <= 4) {
				c = position.col + 1;
			} else {
				c = position.col - 1;
			}

			if (i == 3 || i == 7) {
				r = position.row;
			} else if (4 <= i && i <= 6) {
				r = position.row + 1;
			} else {
				r = position.row - 1;
			}
			try {
				if (gameInstance.gameState.gameMap.map[c][r].getType() != BlockType.WATER) {
					directions.remove(i);
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				directions.remove(i);
			}
		}

		int d = directions.get(CElization.rndMaker.nextInt(directions.size()))
				.intValue();

		if (2 <= d && d <= 4) {
			position.col++;
		} else {
			position.col--;
		}

		if (4 <= d && d <= 6) {
			position.row++;
		} else {
			position.row--;
		}

		/** add food */
		gameInstance.gameState.storedResources
				.add(new NaturalResources(
						(int) (GameParameters.boatFoodProduction * GameParameters.minesExtractionRatioFOOD),
						0, 0, 0, 0));
	}

	/**
	 * @return the position
	 */
	public Coordinates getPosition() {
		return position;
	}

	public void stepBuilding() {
		if (!buildingFinished()) {
			buildingPhase++;
		}
	}

	public boolean buildingFinished() {
		return buildingPhase >= requiredBuildingTime;
	}
}
