/**
 * 
 */
package celization;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import judge.Judge;
import celization.buildings.Building;
import celization.buildings.MainBuilding;
import celization.buildings.Market;
import celization.buildings.Port;
import celization.buildings.Storage;
import celization.buildings.University;
import celization.buildings.extractables.Farm;
import celization.buildings.extractables.GoldMine;
import celization.buildings.extractables.Mine;
import celization.buildings.extractables.StoneMine;
import celization.buildings.extractables.WoodCamp;
import celization.civilians.Civilian;
import celization.civilians.Scholar;
import celization.civilians.Worker;
import celization.civilians.WorkerState;
import celization.civilians.workeractions.Move;
import celization.exceptions.BuildingBusyException;
import celization.exceptions.BuildingFullException;
import celization.exceptions.CannotWorkHereException;
import celization.exceptions.IllegalDuplicateException;
import celization.exceptions.InsufficientResearchesException;
import celization.exceptions.InsufficientResourcesException;
import celization.exceptions.MaximumCapacityReachedException;
import celization.mapgeneration.BlockType;
import celization.mapgeneration.GameMap;

/**
 * @author mjafar
 * 
 */

public class CElization {

	public static Random rndMaker = new Random();

	public GameState gameState = new GameState(new HashMap<String, Civilian>(),
			new HashMap<String, Boat>(), new HashMap<String, Building>(),
			new ArrayList<String>());

	/** New Game constructor */
	public CElization() {
		Judge.initializeJudge();
		initializeGame();
	}

	/** Load Game constructor */
	public CElization(String loadGame) {
		// TODO: add load game
	}

	public void initializeGame() {
		/** make the game map */
		GameParameters.seed = 1;
		gameState.gameMap = new GameMap();

		/** set turn */
		gameState.turn = 0;

		/** Create 'derp' */
		createDerp();

		/** Take care of storage */
		initiatializeStorageCapacities();
	}

	private void initiatializeStorageCapacities() {
		gameState.storageCapacity = new NaturalResources(
				GameParameters.foodCapacity, GameParameters.goldCapacity, 0,
				GameParameters.stoneCapacity, GameParameters.woodCapacity);
		gameState.storedResources = new NaturalResources(GameParameters.food,
				GameParameters.gold, 0, GameParameters.stone,
				GameParameters.wood);

	}

	private void createDerp() {
		Worker w = new Worker("derp");
		Coordinates derpPosition;
		BlockType landUnderDerpFeet;

		do {
			derpPosition = new Coordinates(
					CElization.rndMaker.nextInt(GameParameters.gameMapSize.col),
					CElization.rndMaker.nextInt(GameParameters.gameMapSize.row));

			landUnderDerpFeet = gameState.gameMap.map[derpPosition.col][derpPosition.row]
					.getType(false);

			System.err.println(derpPosition + " "
					+ landUnderDerpFeet.toString());

		} while (landUnderDerpFeet != BlockType.PLAIN);

		w.setPosition(derpPosition);
		w.injectGameInstance(this);
		while (!w.isMature()) {
			w.growUp();
		}
		int diff = (GameParameters.workerUnlockArea.row - 1) / 2;
		gameState.gameMap.unlockCells(new Coordinates(derpPosition.col - diff,
				derpPosition.row - diff), GameParameters.workerUnlockArea);
		gameState.numberOfAliveOnes = 1;
		gameState.civilians.put("derp", w);
	}

	/** Get Game objects by their unique IDs */
	public Building getBuildingByUID(String UID) {
		return gameState.buildings.get(UID);
	}

	public Civilian getCivilianByUID(String UID) {
		return gameState.civilians.get(UID);
	}

	public Worker getWorkerByUID(String UID) {
		return (Worker) getCivilianByUID(UID.replaceFirst("worker:", ""));
	}

	public Scholar getStudentByUID(String UID) {
		return (Scholar) getCivilianByUID(UID.replaceFirst("student:", ""));
	}

	public Boat getBoatByUID(String UID) {
		return gameState.boats.get(UID);
	}

	/** Game actions */
	public String makeNewWorker() throws BuildingBusyException,
			InsufficientResourcesException {
		MainBuilding hq = gameState.getHeadQuarters();

		if (hq.busy()) {
			throw new BuildingBusyException();
		}

		if (!gameState.storedResources.doWeHave(GameParameters.workerMaterial)) {
			throw new InsufficientResourcesException();
		}

		Worker w = new Worker(NameChooser.getFreeName());
		w.injectGameInstance(this);
		gameState.civilians.put(w.getName(), w);
		gameState.storedResources.subtract(GameParameters.workerMaterial);
		hq.startTrainingWorker(w.getName());

		/** find free land around headquarters */
		boolean found = false;

		for (int r = -1; !found && r < GameParameters.mainBuildingSize.row + 1; r++) {
			for (int c = -1; !found
					&& c < GameParameters.mainBuildingSize.col + 1; c++) {
				try {
					if (workerCanGoThere(new Coordinates(c + hq.position.col, r
							+ hq.position.row))
							&& !underBuilding(new Coordinates(c
									+ hq.position.col, r + hq.position.row))) {
						found = true;
						w.setPosition(new Coordinates(c + hq.position.col, r
								+ hq.position.row));
					}
				} catch (ArrayIndexOutOfBoundsException e) {
					// hehehehe
				}
			}
		}

		return String.format("worker:%s", w.getName());
	}

	private boolean underBuilding(Coordinates coordinates) {
		int buildingRow, buildingCol;
		for (Building b : gameState.buildings.values()) {
			buildingRow = b.position.row;
			buildingCol = b.position.col;
			if ((buildingCol <= coordinates.col && coordinates.col < b.size.col
					+ buildingCol)
					&& (buildingRow <= coordinates.row && coordinates.row < b.size.row
							+ buildingRow)) {
				return true;
			}
		}
		return false;
	}

	public String makeNewWorker(boolean force, Coordinates position) {
		Worker w = new Worker(NameChooser.getFreeName());

		w.injectGameInstance(this);
		w.setPosition(position);

		while (!w.isMature()) {
			w.growUp();
		}

		gameState.civilians.put(w.getName(), w);
		gameState.numberOfAliveOnes++;

		return String.format("%s", w.getName());
	}

	public String makeNewScholar() throws InsufficientResourcesException,
			BuildingBusyException, MaximumCapacityReachedException,
			InsufficientResourcesException {
		try {
			gameState.getUniversity();
		} catch (Exception e) {
			throw new InsufficientResourcesException();
		}
		if (gameState.getUniversity().busy()) {
			throw new BuildingBusyException();
		}

		if (!gameState.haveRoomForNewStudent()) {
			throw new MaximumCapacityReachedException();
		}

		if (!gameState.storedResources.doWeHave(GameParameters.scholarMaterial)) {
			throw new InsufficientResourcesException();
		}

		/** take material from resources */
		gameState.storedResources.subtract(GameParameters.scholarMaterial);

		Scholar s = new Scholar(NameChooser.getFreeName());
		gameState.civilians.put(s.getName(), s);
		gameState.getUniversity().startTrainingStudent(s.getName());

		return String.format("student:%s", s.getName());
	}

	public String makeNewScholar(boolean force)
			throws MaximumCapacityReachedException {

		if (!gameState.haveRoomForNewStudent()) {
			throw new MaximumCapacityReachedException();
		}

		Scholar s = new Scholar(NameChooser.getFreeName());
		s.finishInstantly();

		gameState.civilians.put(s.getName(), s);
		gameState.numberOfAliveOnes++;

		return String.format("student:%s", s.getName());
	}

	public String makeNewBuilding(String workerName, Coordinates position,
			String buildingType) throws InsufficientResourcesException,
			InsufficientResearchesException, IllegalArgumentException,
			IllegalDuplicateException {

		String name = newBuildingID(buildingType);
		Building b = newBuildingInstance(buildingType);

		if (b == null) {
			throw new IllegalArgumentException(String.valueOf(buildingType));
		}

		checkAvailabilityOfBuildBuilding(b);

		/** Subtract from resources and start building */
		gameState.storedResources.subtract(b.requiredResources);
		b.injectGameInstance(this);
		b.buildAddBuilderWorker(workerName);
		b.buildStartBuilding(position);
		gameState.buildings.put(name, b);
		gameState.unfinishedBuildings.add(name);
		/** mark blocks under this building as unavailable */
		for (int i = 0; i < b.size.col; i++) {
			for (int j = 0; j < b.size.row; j++) {
				PathFinder.availableBlocks[i + position.col][j + position.row] = false;
			}
		}
		return name;
	}

	public void checkAvailabilityOfBuildBuilding(Building b)
			throws InsufficientResourcesException,
			InsufficientResearchesException, IllegalArgumentException,
			IllegalDuplicateException {
		/** check resources */
		if (!gameState.storedResources.doWeHave(b.requiredResources)) {
			throw new InsufficientResourcesException();
		}
		checkResearches(b);
	}

	public void checkAvailabilityOfBuildBuilding(String t)
			throws InsufficientResearchesException, IllegalArgumentException,
			IllegalDuplicateException {
		checkResearches(Judge.buildingTypes.get(t));
	}

	private void checkResearches(Building b)
			throws InsufficientResearchesException, IllegalArgumentException,
			IllegalDuplicateException {
		if (b instanceof Farm
				&& !gameState.courseManager.hasBeenDone("Agriculture")) {
			throw new InsufficientResearchesException();
		}
		if (b instanceof Mine && !gameState.courseManager.hasBeenDone("Mining")) {
			throw new InsufficientResearchesException();
		}
		if (b instanceof WoodCamp
				&& !gameState.courseManager.hasBeenDone("Lumber Mill")) {
			throw new InsufficientResearchesException();
		}
		if (b instanceof Port
				&& !gameState.courseManager.hasBeenDone("Fishing")) {
			throw new InsufficientResearchesException();
		}
		if (b instanceof Market
				&& !gameState.courseManager.hasBeenDone("Market")) {
			throw new InsufficientResearchesException();
		}

	}

	public String makeNewBuilding(Coordinates position, String buildingType)
			throws IllegalDuplicateException {
		String name;
		name = newBuildingID(buildingType);
		Building b = newBuildingInstance(buildingType);
		b.injectGameInstance(this);
		b.buildStartBuilding(position);
		b.finishInstantly();
		gameState.buildings.put(name, b);
		/** mark blocks under this building as unavailable */
		for (int i = 0; i < b.size.col; i++) {
			for (int j = 0; j < b.size.row; j++) {
				PathFinder.availableBlocks[i + position.col][j + position.row] = false;
			}
		}
		return name;
	}

	public void sellBuilding(String name) {
		getBuildingByUID(name).sell();
	}

	public boolean workerCanGoThere(Coordinates pos) {
		if (pos.row < 0 || pos.col < 0
				|| pos.row >= GameParameters.gameMapSize.row
				|| pos.col >= GameParameters.gameMapSize.col) {
			return false;
		}
		BlockType blockType = gameState.gameMap.get(pos).getType();
		switch (blockType) {
		case PLAIN:
		case UNKNOWN:
		case JUNGLE:
		default:
			return true;
		case WATER:
			return false;
		case MOUNTAIN:
			// TODO: military researches
			return false;
		}
	}

	public Building newBuildingInstance(String buildingType) {
		switch (Integer.parseInt(buildingType)) {
		case 1:
			return new MainBuilding();
		case 2:
			return new University();
		case 3:
			return new GoldMine();
		case 4:
			return new StoneMine();
		case 5:
			return new Farm();
		case 6:
			return new WoodCamp();
		case 7:
			return new Storage();
		case 8:
			return new Market();
		case 9:
			return new Port();
		default:
			return null;
		}
	}

	public String newBuildingID(String buildingType)
			throws IllegalDuplicateException {
		if (!Judge.buildingTypes.containsKey(buildingType)) {
			return null;
		}
		if (Judge.buildingTypes.get(buildingType) instanceof MainBuilding) {
			if (getBuildingByUID(GameParameters.headquartersID) != null) {
				throw new IllegalDuplicateException();
			}
			return GameParameters.headquartersID;
		} else if (Judge.buildingTypes.get(buildingType) instanceof University) {
			if (getBuildingByUID(GameParameters.universityID) != null) {
				throw new IllegalDuplicateException();
			}
			return GameParameters.universityID;
		} else {
			return String.format("%s-%d", Judge.buildingTypes.get(buildingType)
					.getClassID(), gameState.buildingsNumberingIndex++);
		}
	}

	public void goAndWork(String workerID, String workplaceID)
			throws CannotWorkHereException, BuildingFullException {
		Building workplace = getBuildingByUID(workplaceID);
		Worker worker = getWorkerByUID(workerID);

		Coordinates workplaceCoordinates = workplace.position;
		// it may throw BuildingFullException, we don't try...catch it
		// because we want it to be re-throw-ed !
		workplace.addOccupiedWorker(workerID);
		// if building was busy worker won't go there
		try {
			worker.addAction(new Move(workplaceCoordinates));
			if (workplace instanceof GoldMine) {
				worker.workState = WorkerState.MiningGold;
			} else if (workplace instanceof StoneMine) {
				worker.workState = WorkerState.MiningStone;
			} else if (workplace instanceof Farm) {
				worker.workState = WorkerState.Farming;
			} else if (workplace instanceof WoodCamp) {
				worker.workState = WorkerState.WoodCamp;
			}
		} catch (IllegalArgumentException e) {
			// this will not happen :D
		}
	}

	public String makeNewBoat(String portID) {
		Boat b = new Boat();
		String boatID = String.format("boat:%d", gameState.boats.size());
		b.injectGameInstance(this);
		b.addToPort(portID);
		gameState.boats.put(boatID, b);

		return boatID;
	}

	public void exchangeResources(int amount, String from, String to)
			throws InsufficientResourcesException {
		if (gameState.storedResources.get(from) < amount) {
			throw new InsufficientResourcesException();
		}

		double soorat = 1, makhraj = 1;

		if ("gold".equals(from)) {
			makhraj = GameParameters.priceOfGold;
			gameState.storedResources.numberOfGolds -= amount;
		} else if ("stone".equals(from)) {
			makhraj = GameParameters.priceOfStone;
			gameState.storedResources.numberOfStones -= amount;
		} else if ("lumber".equals(from)) {
			makhraj = GameParameters.priceOfWood;
			gameState.storedResources.numberOfWoods -= amount;
		} else if ("food".equals(from)) {
			makhraj = GameParameters.priceOfFood;
			gameState.storedResources.numberOfFood -= amount;
		}
		if ("gold".equals(to)) {
			soorat = GameParameters.priceOfGold;
			gameState.storedResources.numberOfGolds += amount * soorat
					/ makhraj;
		} else if ("stone".equals(to)) {
			soorat = GameParameters.priceOfStone;
			gameState.storedResources.numberOfStones += amount * soorat
					/ makhraj;
		} else if ("lumber".equals(to)) {
			soorat = GameParameters.priceOfWood;
			gameState.storedResources.numberOfWoods += amount * soorat
					/ makhraj;
		} else if ("food".equals(to)) {
			soorat = GameParameters.priceOfFood;
			gameState.storedResources.numberOfFood += amount * soorat / makhraj;
		}

		gameState.manageStorageOverHead();
	}

	public boolean aroundBuilding(Coordinates workerLocation,
			Coordinates location, Coordinates buildingSize) {

		// Distance from one of building blocks is 1
		for (int row = location.row; row < location.row + buildingSize.row; row++) {
			for (int col = 0; col < location.col + buildingSize.col; col++) {
				if (Math.abs(workerLocation.row - row) <= 1
						|| Math.abs(workerLocation.col - col) <= 1) {
					return true;
				}
			}
		}
		return false;
	}

	public boolean canBuildThere(Coordinates location, String buildingType) {
		BlockType requiredType = null;
		Building targetBuildingInstance = Judge.buildingTypes.get(buildingType);

		/** check whether a building can be built there or not */
		switch (Integer.parseInt(buildingType)) {
		case 1: // main building
		case 2: // university
		case 5: // farm
		case 7: // storage
		case 8: // market
			requiredType = BlockType.PLAIN;
			break;
		case 3: // gold mine
		case 4: // stone mine
			requiredType = BlockType.MOUNTAIN;
			break;
		case 6: // wood camp
			requiredType = BlockType.JUNGLE;
			break;
		case 9: // port
			requiredType = BlockType.WATER;
			break;
		}

		Coordinates currentProcessedBlock = new Coordinates(0, 0);
		for (int i = 0; i < targetBuildingInstance.size.row; i++) {
			for (int j = 0; j < targetBuildingInstance.size.col; j++) {
				currentProcessedBlock.row = location.row + j;
				currentProcessedBlock.col = location.col + i;

				if (gameState.gameMap.get(currentProcessedBlock).getType() != requiredType) {
					return false;
				}
			}
		}

		return true;
	}

	public boolean underBuilding(Coordinates location, Coordinates l,
			Coordinates size) {
		Coordinates currentProcessedBlock = new Coordinates(0, 0);
		for (int i = 0; i < size.row; i++) {
			for (int j = 0; j < size.col; j++) {
				currentProcessedBlock.row = l.row + j;
				currentProcessedBlock.col = l.col + i;

				if (location.equals(currentProcessedBlock)) {
					return false;
				}
			}
		}

		return true;
	}

	public boolean checkWorkerUnderBuilding(Coordinates location,
			Coordinates size) {

		for (Civilian w : gameState.civilians.values()) {
			if (w instanceof Worker
					&& underBuilding(w.getPos(), location, size)) {
				return false;
			}
		}

		return true;
	}
}
