/**
 * 
 */
package celization.buildings;

import java.util.ArrayList;

import celization.CElization;
import celization.Coordinates;
import celization.GameParameters;
import celization.NaturalResources;
import celization.needsGameInstance;
import celization.buildings.extractables.Farm;
import celization.buildings.extractables.GoldMine;
import celization.buildings.extractables.StoneMine;
import celization.buildings.extractables.WoodCamp;
import celization.civilians.Worker;
import celization.civilians.WorkerState;
import celization.exceptions.BuildingFullException;
import celization.exceptions.CannotWorkHereException;

/**
 * @author mjafar
 * 
 */
public abstract class Building implements needsGameInstance {
	public Coordinates position;
	public Coordinates size;
	public NaturalResources requiredResources;
	public ArrayList<String> builderWorkers = new ArrayList<String>(1);
	public CElization gameInstance;
	public ArrayList<String> occupiedWorkers = new ArrayList<String>(1);

	protected double requiredBuildingTime;
	protected double buildingPhase;

	@Override
	public void injectGameInstance(celization.CElization game) {
		gameInstance = game;
	}

	public boolean buildStartBuilding(Coordinates position) {
		buildingPhase = 0;
		this.position = position;
		return true;
	}

	public void finishInstantly() {
		buildingPhase = requiredBuildingTime;
		buildBuildingFinishedCallBack();
	}

	public void buildAddBuilderWorker(String workerID) {
		builderWorkers.add(workerID);

		Worker worker = gameInstance.getWorkerByUID(workerID);
		worker.workState = WorkerState.Building;
		// a little messy look code
		// to prevent the worker from
		// farther moves and make
		// him/her to stay where he/she is.
		worker.move(worker.getPos());

		requiredBuildingTime -= (int) (worker
				.getExperience(GameParameters.ExpCivilEng) * 2);
		worker.excersize(GameParameters.ExpCivilEng);
	}

	public void buildAddBuilderWorker(String[] workingWorkers) {
		builderWorkers = new ArrayList<String>(workingWorkers.length);

		for (String name : workingWorkers) {
			builderWorkers.add(name);
		}

		for (String workerName : builderWorkers) {
			Worker worker = gameInstance.getWorkerByUID(workerName);
			// a little messy look code
			// to prevent the worker from
			// farther moves and make
			// him/her to stay where he/she is.
			worker.move(worker.getPos());

			worker.workState = WorkerState.Building;
			requiredBuildingTime -= worker
					.getExperience(GameParameters.ExpCivilEng) * 2;
		}
	}

	public void buildStep() {
		/** remove dead workers */
		for (String name : builderWorkers) {
			if (!gameInstance.getWorkerByUID(name).stillAlive()) {
				builderWorkers.remove(name);
			}
		}
		/** have alive workers */
		if (builderWorkers.size() > 0) {
			buildingPhase += 1;
		}
	}

	public boolean buildBuildingFinished() {
		return buildingPhase >= requiredBuildingTime;
	}

	public void buildBuildingFinishedCallBack() {
		/** free building workers */
		for (String workerID : builderWorkers) {
			gameInstance.getWorkerByUID(workerID).workState = WorkerState.Free;
			gameInstance.getWorkerByUID(workerID).excersize(
					GameParameters.ExpCivilEng);
		}
		builderWorkers.clear();

		/** add storage capacities */
		if (this instanceof Storage) {
			gameInstance.gameState.storageCapacity
					.add(GameParameters.StorageExtraCapacity);
		}
	}

	public void sell() {
		gameInstance.gameState.storedResources.add(new NaturalResources(
				requiredResources.numberOfFood / 2,
				requiredResources.numberOfGolds / 2,
				requiredResources.numberOfScience / 2,
				requiredResources.numberOfStones / 2,
				requiredResources.numberOfWoods / 2));

		if (this instanceof Storage) {
			gameInstance.gameState.storageCapacity
					.subtract(GameParameters.StorageExtraCapacity);
		}

		gameInstance.gameState.buildings.remove(this);
	}

	public void addOccupiedWorker(String workerID)
			throws BuildingFullException, CannotWorkHereException {
		/** building full */
		if (occupiedWorkers.size() == GameParameters.maximumNumberOfWorkers) {
			throw new BuildingFullException();
		}
		/** Buildings which don't need a worker to work in */
		if (this instanceof Port || this instanceof MainBuilding
				|| this instanceof Market || this instanceof University
				|| this instanceof Storage) {
			throw new CannotWorkHereException();
		}
		/** Hire the worker */
		occupiedWorkers.add(workerID);
	}

	public boolean isActive() {
		/** worker should be in the building */
		for (String workerName : occupiedWorkers) {
			if (gameInstance.getCivilianByUID(workerName).getPos()
					.equals(this.position)) {
				return true;
			}
		}

		return false;
	}

	public String getClassID() {
		if (this instanceof MainBuilding) {
			return GameParameters.headquartersID;
		} else if (this instanceof University) {
			return GameParameters.universityID;
		} else if (this instanceof GoldMine) {
			return GameParameters.goldmineID;
		} else if (this instanceof WoodCamp) {
			return GameParameters.woodcampID;
		} else if (this instanceof Storage) {
			return GameParameters.storageID;
		} else if (this instanceof Market) {
			return GameParameters.marketID;
		} else if (this instanceof Port) {
			return GameParameters.portID;
		} else if (this instanceof Farm) {
			return GameParameters.farmID;
		} else if (this instanceof StoneMine) {
			return GameParameters.stonemineID;
		} else {
			return null;
		}
	}

	public abstract boolean busy();

	public abstract String step();

}
