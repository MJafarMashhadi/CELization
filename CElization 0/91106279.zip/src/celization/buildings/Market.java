/**
 * 
 */
package celization.buildings;

import celization.GameParameters;

/**
 * @author mjafar
 * 
 */

public final class Market extends Building {
	/**
	 * 
	 */
	public Market() {
		super();
		requiredBuildingTime = GameParameters.marketETA;
		requiredResources = GameParameters.marketMaterial;
		size = GameParameters.marketSize;
	}

	@Override
	public boolean busy() {
		return false;
	}

	@Override
	public String step() {
		return null;
	}
}
