/**
 * 
 */
package celization.buildings.extractables;

import celization.GameParameters;

/**
 * @author mjafar
 * 
 */
public final class Farm extends Mine {

	public Farm() {
		super();
		size = GameParameters.farmSize;
		requiredBuildingTime = GameParameters.farmETA;
		requiredResources = GameParameters.farmMaterial;
	}

	@Override
	public boolean busy() {
		return false;
	}

	@Override
	public String step() {
		return null;
	}

}
