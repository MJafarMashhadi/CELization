/**
 * 
 */
package celization.buildings.extractables;

import celization.GameParameters;

/**
 * @author mjafar
 * 
 */

public final class StoneMine extends Mine {
	public StoneMine() {
		super();
		size = GameParameters.stoneMineSize;
		requiredBuildingTime = GameParameters.stoneMineETA;
		requiredResources = GameParameters.stoneMineMaterial;
	}

	@Override
	public boolean busy() {
		return false;
	}

	@Override
	public String step() {
		return null;
	}

}
