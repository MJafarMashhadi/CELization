/**
 * 
 */
package celization.buildings.extractables;

import celization.GameParameters;

/**
 * @author mjafar
 * 
 */

public final class GoldMine extends Mine {
	public GoldMine() {
		super();
		size = GameParameters.goldMineSize;
		requiredBuildingTime = GameParameters.goldMineETA;
		requiredResources = GameParameters.goldMineMaterial;
	}

	@Override
	public boolean busy() {
		return false;
	}

	@Override
	public String step() {
		return null;
	}

}
