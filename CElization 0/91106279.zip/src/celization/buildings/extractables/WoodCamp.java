/**
 * 
 */
package celization.buildings.extractables;

import celization.GameParameters;

/**
 * @author mjafar
 * 
 */
public final class WoodCamp extends Mine {

	public WoodCamp() {
		super();
		size = GameParameters.woodCampSize;
		requiredBuildingTime = GameParameters.woodCampETA;
		requiredResources = GameParameters.woodCampMaterial;
	}

	@Override
	public boolean busy() {
		return false;
	}

	@Override
	public String step() {
		return null;
	}

}
