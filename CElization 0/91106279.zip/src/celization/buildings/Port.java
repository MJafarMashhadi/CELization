/**
 * 
 */
package celization.buildings;

import java.util.ArrayList;

import celization.GameParameters;

/**
 * @author mjafar
 * 
 */
// TODO: code
public final class Port extends Building {

	/**
	 * 
	 */
	ArrayList<String> boats = new ArrayList<String>();

	public Port() {
		super();
		requiredBuildingTime = GameParameters.portETA;
		requiredResources = GameParameters.portMaterial;
		size = GameParameters.portSize;
	}

	public void addBoat(String b) {
		boats.add(b);
	}

	@Override
	public boolean busy() {
		for (String boatID : boats) {
			if (!gameInstance.getBoatByUID(boatID).buildingFinished()) {
				return false;
			}
		}
		return false;
	}

	@Override
	public String step() {
		for (String boatID : boats) {
			gameInstance.getBoatByUID(boatID).wander();
		}
		return null;
	}
}
