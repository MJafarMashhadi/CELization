/**
 * 
 */
package celization.buildings;

import judge.Judge;
import celization.GameParameters;
import celization.NaturalResources;
import celization.civilians.Scholar;
import celization.exceptions.BuildingBusyException;
import celization.exceptions.InsufficientResearchesException;
import celization.exceptions.InsufficientResourcesException;

/**
 * @author mjafar
 * 
 */
public final class University extends Building {

	private String studentBeingTrained = new String();

	/**
	 * 
	 */
	public University() {
		super();
		studentBeingTrained = null;
		requiredBuildingTime = GameParameters.universityETA;
		requiredResources = GameParameters.universityMaterial;
		size = GameParameters.universitySize;
	}

	public void startResearch(String courseName)
			throws InsufficientResourcesException,
			InsufficientResearchesException, BuildingBusyException {
		if (!gameInstance.gameState.courseManager.dependencyMet(courseName)) {
			throw new InsufficientResearchesException();
		}
		if (!gameInstance.gameState.storedResources
				.doWeHave(gameInstance.gameState.courseManager.get(courseName).requiredResources)) {
			throw new InsufficientResourcesException();
		}

		if (this.busy()) {
			throw new BuildingBusyException();
		}
		gameInstance.gameState.storedResources
				.subtract(gameInstance.gameState.courseManager.get(courseName).requiredResources);
		gameInstance.gameState.courseManager.startResearch(courseName);
	}

	public String currentResearch() {
		return gameInstance.gameState.courseManager.inProgress;
	}

	public void startTrainingStudent(String name) {
		studentBeingTrained = name;
	}

	@Override
	public boolean busy() {
		if (gameInstance.gameState.courseManager.inProgress != null
				|| studentBeingTrained != null) {
			return true;
		}
		return false;
	}

	public String step() {
		/** add to knowledge resource */
		gameInstance.gameState.storedResources.add(new NaturalResources(0, 0,
				gameInstance.gameState.getNumberOfStudents(true), 0, 0));

		/** progress training students */
		if (studentBeingTrained != null) {
			Scholar s = gameInstance.getStudentByUID(studentBeingTrained);

			s.growUp();
			if (s.isMature()) {
				studentBeingTrained = null;
				gameInstance.gameState.numberOfAliveOnes++;
				return String.format("scholar trained student:%s", s.getName());
			} else {
				return null;
			}
		}

		/** progress researches */
		if (gameInstance.gameState.courseManager.inProgress != null) {
			String finishedReserchName = gameInstance.gameState.courseManager
					.progress();
			if (finishedReserchName != null) {
				gameInstance.gameState
						.takeEffectOfResearches(finishedReserchName);
				return String.format("research finished %d",
						Judge.researchIDSI.get(finishedReserchName));
			} else {
				return null;
			}
		}

		return null;
	}
}
