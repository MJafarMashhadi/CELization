/**
 * 
 */
package celization.buildings;

import celization.GameParameters;
import celization.civilians.Worker;

/**
 * @author mjafar
 * 
 */
public final class MainBuilding extends Building {

	private String workerBeingTrained;

	/**
	 * 
	 */
	public MainBuilding() {
		super();
		requiredBuildingTime = GameParameters.mainBuildingETA;
		requiredResources = GameParameters.mainBuildingMaterial;
		size = GameParameters.mainBuildingSize;
		workerBeingTrained = null;
	}

	public void startTrainingWorker(String name) {
		workerBeingTrained = name;
	}

	@Override
	public boolean busy() {
		return (workerBeingTrained != null);
	}

	@Override
	public String step() {
		if (workerBeingTrained == null) {
			return null;
		}

		Worker w = gameInstance.getWorkerByUID(workerBeingTrained);
		w.growUp();
		if (w.isMature()) {
			workerBeingTrained = null;
			gameInstance.gameState.numberOfAliveOnes++;
			return String.format("worker trained worker:%s", w.getName());
		}

		return null;
	}

}
