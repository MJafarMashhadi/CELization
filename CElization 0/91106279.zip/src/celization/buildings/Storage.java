/**
 * 
 */
package celization.buildings;

import celization.GameParameters;

/**
 * @author mjafar
 * 
 */
public final class Storage extends Building {
	public Storage() {
		super();
		size = GameParameters.stockpileSize;
		requiredBuildingTime = GameParameters.stockpileETA;
		requiredResources = GameParameters.stockpileMaterial;
	}

	@Override
	public boolean busy() {
		return false;
	}

	@Override
	public String step() {
		return null;
	}

}
