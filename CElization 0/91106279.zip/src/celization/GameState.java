package celization;

import java.util.ArrayList;
import java.util.Map;

import celization.buildings.Building;
import celization.buildings.MainBuilding;
import celization.buildings.University;
import celization.civilians.Civilian;
import celization.civilians.Scholar;
import celization.civilians.Worker;
import celization.exceptions.InsufficientResourcesException;
import celization.mapgeneration.GameMap;
import celization.research.CourseManager;

public class GameState /* implements Serializable */{
	public int turn;
	public GameMap gameMap;
	public NaturalResources storedResources;
	public NaturalResources storageCapacity;
	public Map<String, Civilian> civilians;
	public Map<String, Boat> boats;
	public Map<String, Building> buildings;
	public ArrayList<String> unfinishedBuildings;
	public int numberOfAliveOnes;
	public ArrayList<String> events = new ArrayList<String>();

	public CourseManager courseManager = new CourseManager();

	public int buildingsNumberingIndex = 0;

	public GameState(Map<String, Civilian> civilians, Map<String, Boat> boats,
			Map<String, Building> buildings,
			ArrayList<String> unfinishedBuildings) {
		this.civilians = civilians;
		this.boats = boats;
		this.buildings = buildings;
		this.unfinishedBuildings = unfinishedBuildings;
	}

	public void step() {
		/** do this turn's stuff */
		events.add(stepConsumeFood());
		events.addAll(stepBuildBoats());
		events.addAll(stepBuildBuildings());
		events.addAll(stepExtractFromMinesAndTrainPeople());
		stepMoveBoats();
		stepWorkerActions();
		stepGetTaxes();

		/** Manage Storage OverHead */
		manageStorageOverHead();
		/** clean up */
		while (events.contains(null)) {
			events.remove(null);
		}
		/** increases turn number */
		turn++;
	}

	public void manageStorageOverHead() {
		if (storedResources.numberOfFood > storageCapacity.numberOfFood) {
			storedResources.numberOfFood = storageCapacity.numberOfFood;
		}
		if (storedResources.numberOfGolds > storageCapacity.numberOfGolds) {
			storedResources.numberOfGolds = storageCapacity.numberOfGolds;
		}
		if (storedResources.numberOfStones > storageCapacity.numberOfStones) {
			storedResources.numberOfStones = storageCapacity.numberOfStones;
		}
		if (storedResources.numberOfWoods > storageCapacity.numberOfWoods) {
			storedResources.numberOfWoods = storageCapacity.numberOfWoods;
		}
	}

	private void stepGetTaxes() {
		if (GameParameters.canGetTax) {
			storedResources.add(new NaturalResources(0, (int) Math
					.floor(numberOfAliveOnes / 4), 0, 0, 0));
		}
	}

	private void stepMoveBoats() {
		for (Boat b : boats.values()) {
			if (!b.buildingFinished()) {
				continue;
			}
			b.wander();
		}
	}

	/**
	 * 
	 */
	private void stepWorkerActions() {
		/** move moving workers */
		for (Civilian w : civilians.values()) {
			if (w instanceof Worker) {
				((Worker) w).step();
			}
		}
	}

	/** Extract resources from mines and move boats in order to do fishings */
	private ArrayList<String> stepExtractFromMinesAndTrainPeople() {
		ArrayList<String> returnValue = new ArrayList<String>();
		for (Building b : buildings.values()) {
			returnValue.add(b.step());
		}

		return returnValue;
	}

	private ArrayList<String> stepBuildBoats() {
		ArrayList<String> finishedboatsInThisTurn = new ArrayList<String>();
		for (String b : boats.keySet()) {
			if (boats.get(b).buildingFinished()) {
				continue;
			}

			boats.get(b).stepBuilding();
			if (boats.get(b).buildingFinished()) {
				finishedboatsInThisTurn
						.add(String.format("boat trained %s", b));
			}
		}
		return finishedboatsInThisTurn;
	}

	/** build buildings */
	private ArrayList<String> stepBuildBuildings() {
		ArrayList<String> finishedBuildingsInThisTurn = new ArrayList<String>();
		//
		String buildingID;
		for (int i = unfinishedBuildings.size() - 1; i >= 0; i--) {
			buildingID = unfinishedBuildings.get(i);

			buildings.get(buildingID).buildStep();
			if (buildings.get(buildingID).buildBuildingFinished()) {
				buildings.get(buildingID).buildBuildingFinishedCallBack();
				unfinishedBuildings.remove(i);
				finishedBuildingsInThisTurn.add(String.format(
						"construction finished %s", buildingID));
			}
		}

		return finishedBuildingsInThisTurn;
	}

	/** consume food */
	private String stepConsumeFood() {
		/** Feed people */
		for (Civilian currentCivilian : civilians.values()) {
			if (currentCivilian.stillAlive() && currentCivilian.isMature()) {
				storedResources.numberOfFood -= currentCivilian
						.getFoodConsumption();
			}
		}
		/** kill hungry ones */
		if (storedResources.numberOfFood <= 0) {
			storedResources.numberOfFood = 0;
			if (numberOfAliveOnes > 0) {
				Civilian lesMiserable;
				do {
					lesMiserable = civilians
							.get(civilians.keySet().toArray()[CElization.rndMaker
									.nextInt(civilians.size())]);
				} while (!lesMiserable.stillAlive());

				lesMiserable.die();
				numberOfAliveOnes--;

				/** notify game */
				if (lesMiserable.getName().equals("derp")) {
					return "worker died derp";
				} else {
					return String.format("%s died %s:%s",
							lesMiserable.getTypeString(),
							lesMiserable.getTypeString(),
							lesMiserable.getName());
				}
			}
		}

		return null;
	}

	/** events management */
	public void clearEvents() {
		events.clear();
	}

	public String[] getEvents() {
		return events.toArray(new String[events.size()]);
	}

	/** apply researches' effects in the game */
	public void takeEffectOfResearches(String name) {
		if (name.equals("Ranching")) {
			GameParameters.minesExtractionRatioFOOD *= 1.20;
		} else if (name.equals("Irrigation")) {
			GameParameters.minesExtractionRatioFOOD *= 1.30;
		} else if (name.equals("Refinery")) {
			GameParameters.minesExtractionRatioSTONE *= 1.20;
		} else if (name.equals("Carpentry")) {
			GameParameters.minesExtractionRatioWOOD *= 1.20;
		} else if (name.equals("Economy")) {
			GameParameters.minesExtractionRatioGOLD *= 1.05;
		} else if (name.equals("Micro Economy")) {
			GameParameters.workerPocketCapacity *= 2;
		} else if (name.equals("Macro Economy")) {
			GameParameters.minesExtractionRatioGOLD *= 1.20;
		} else if (name.equals("Parsimony")) {

		} else if (name.equals("Tax")) {
			GameParameters.canGetTax = true;
		} else if (name.equals("Team Work")) {
			GameParameters.maximumNumberOfWorkers *= 2;
		} else if (name.equals("Science")) {
			storedResources.numberOfScience += 50;
		} else if (name.equals("Alphabet")) {

		} else if (name.equals("Mathematics")) {

		} else if (name.equals("Engineering")) {
			GameParameters.mainBuildingETA *= 3 / 4;
			GameParameters.universityETA *= 3 / 4;
			GameParameters.goldMineETA *= 3 / 4;
			GameParameters.stoneMineETA *= 3 / 4;
			GameParameters.woodCampETA *= 3 / 4;
			GameParameters.farmETA *= 3 / 4;
			GameParameters.portETA *= 3 / 4;
			GameParameters.marketETA *= 3 / 4;
			GameParameters.stockpileETA *= 3 / 4;
		} else if (name.equals("School")) {
			GameParameters.maximumNumberOfStudents += 3;
		} else if (name.equals("University")) {
			GameParameters.maximumNumberOfStudents += 6;
		} else if (name.equals("CERN")) {
			GameParameters.maximumNumberOfStudents = -1;
		}
	}

	/** train new student checks */
	public int getNumberOfStudents() {
		int numberOfStudents = 0;
		for (Civilian c : civilians.values()) {
			if (c instanceof Scholar && c.stillAlive()) {
				numberOfStudents++;
			}
		}

		return numberOfStudents;
	}

	public int getNumberOfStudents(boolean shouldBeMature) {
		if (shouldBeMature == false) {
			return getNumberOfStudents();
		} else {
			int numberOfStudents = 0;
			for (Civilian c : civilians.values()) {
				if (c instanceof Scholar && c.isMature() && c.stillAlive()) {
					numberOfStudents++;
				}
			}

			return numberOfStudents;
		}
	}

	public boolean haveRoomForNewStudent() {
		return (GameParameters.maximumNumberOfStudents == -1 || getNumberOfStudents() < GameParameters.maximumNumberOfStudents);
	}

	/**
	 * get unique buildings references
	 * 
	 * @throws InsufficientResourcesException
	 */
	public MainBuilding getHeadQuarters() throws InsufficientResourcesException {
		if (!buildings.containsKey(GameParameters.headquartersID)) {
			throw new InsufficientResourcesException(
					"Do not have main building");
		}
		return (MainBuilding) buildings.get(GameParameters.headquartersID);
	}

	public University getUniversity() throws InsufficientResourcesException {
		if (!buildings.containsKey(GameParameters.universityID)) {
			throw new InsufficientResourcesException("Do not have university");
		}
		return (University) buildings.get(GameParameters.universityID);
	}

}