/**
 * 
 */
package celization.exceptions;

/**
 * @author mjafar
 * 
 */
@SuppressWarnings("serial")
public final class BuildingFullException extends Exception {

	/**
	 * 
	 */
	public BuildingFullException() {
	}

	/**
	 * @param arg0
	 */
	public BuildingFullException(String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public BuildingFullException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public BuildingFullException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
