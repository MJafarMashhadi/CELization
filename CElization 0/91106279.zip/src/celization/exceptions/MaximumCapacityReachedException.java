/**
 * 
 */
package celization.exceptions;

/**
 * @author mjafar
 * 
 */
@SuppressWarnings("serial")
public final class MaximumCapacityReachedException extends Exception {

	/**
	 * 
	 */
	public MaximumCapacityReachedException() {
	}

	/**
	 * @param arg0
	 */
	public MaximumCapacityReachedException(String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public MaximumCapacityReachedException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public MaximumCapacityReachedException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
