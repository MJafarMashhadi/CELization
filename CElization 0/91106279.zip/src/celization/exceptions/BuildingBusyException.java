/**
 * 
 */
package celization.exceptions;

/**
 * @author mjafar
 * 
 */
@SuppressWarnings("serial")
public final class BuildingBusyException extends Exception {

	/**
	 * 
	 */
	public BuildingBusyException() {
	}

	/**
	 * @param arg0
	 */
	public BuildingBusyException(String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public BuildingBusyException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public BuildingBusyException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
