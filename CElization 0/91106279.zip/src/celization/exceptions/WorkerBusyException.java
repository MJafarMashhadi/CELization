/**
 * 
 */
package celization.exceptions;

/**
 * @author mjafar
 * 
 */
@SuppressWarnings("serial")
public final class WorkerBusyException extends Exception {

	/**
	 * 
	 */
	public WorkerBusyException() {
	}

	/**
	 * @param arg0
	 */
	public WorkerBusyException(String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public WorkerBusyException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public WorkerBusyException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
