/**
 * 
 */
package celization.exceptions;

/**
 * @author mjafar
 * 
 */
@SuppressWarnings("serial")
public final class InsufficientResourcesException extends Exception {

	/**
	 * 
	 */
	public InsufficientResourcesException() {
	}

	/**
	 * @param arg0
	 */
	public InsufficientResourcesException(String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public InsufficientResourcesException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public InsufficientResourcesException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
