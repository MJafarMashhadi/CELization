/**
 * 
 */
package celization.exceptions;

/**
 * @author mjafar
 * 
 */
@SuppressWarnings("serial")
public final class IllegalDuplicateException extends Exception {

	/**
	 * 
	 */
	public IllegalDuplicateException() {
	}

	/**
	 * @param arg0
	 */
	public IllegalDuplicateException(String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public IllegalDuplicateException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public IllegalDuplicateException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
