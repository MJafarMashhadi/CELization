/**
 * 
 */
package celization.exceptions;

/**
 * @author mjafar
 * 
 */
@SuppressWarnings("serial")
public final class CannotWorkHereException extends Exception {

	/**
	 * 
	 */
	public CannotWorkHereException() {
	}

	/**
	 * @param message
	 */
	public CannotWorkHereException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public CannotWorkHereException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public CannotWorkHereException(String message, Throwable cause) {
		super(message, cause);
	}

}
