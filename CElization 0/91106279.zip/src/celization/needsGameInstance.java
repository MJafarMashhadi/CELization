package celization;

public interface needsGameInstance {

	public abstract void injectGameInstance(CElization game);

}