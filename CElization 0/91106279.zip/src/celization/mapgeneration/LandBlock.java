/**
 * 
 */
package celization.mapgeneration;

import celization.Coordinates;
import celization.NaturalResources;

/**
 * @author mjafar
 * 
 */

public class LandBlock {
	private Coordinates coordinates;

	private BlockType blockType;

	public boolean locked;

	private NaturalResources availableResources;
	private double height;

	public LandBlock(int col, int row, BlockType type, double height) {
		coordinates = new Coordinates(col, row);
		blockType = type;

		locked = true;

		availableResources = new NaturalResources(blockType);
		this.height = height;
	}

	/**
	 * @return the coordinates
	 */
	public Coordinates getCoordinates() {
		return coordinates;
	}

	/**
	 * @return the height
	 */
	public double getHeight() {
		return height;
	}

	public BlockType getType(boolean doNotShowLocked) {
		if (locked && doNotShowLocked)
			return BlockType.UNKNOWN;

		return blockType;
	}

	public BlockType getType() {
		return getType(true);
	}

	public void unLock() {
		locked = false;
	}

	public void setResources(NaturalResources naturalResources) {
		availableResources = naturalResources;
	}

	public NaturalResources getResources() {
		return availableResources;
	}

}
