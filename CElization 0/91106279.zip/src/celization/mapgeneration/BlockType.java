/**
 * 
 */
package celization.mapgeneration;

/**
 * @author mjafar
 * 
 */
public enum BlockType {
	PLAIN, MOUNTAIN, JUNGLE, WATER, UNKNOWN
};
