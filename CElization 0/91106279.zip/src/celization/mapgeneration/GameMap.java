/**
 * 
 */
package celization.mapgeneration;

import celization.Coordinates;
import celization.GameParameters;
import celization.PathFinder;

/**
 * @author mjafar
 * 
 */
public class GameMap {
	/** map matrix */
	public LandBlock[][] map;
	public PerlinNoiseGenerator noiseGenerator;

	public GameMap() {
		/** initialize map variables */
		map = new LandBlock[GameParameters.gameMapSize.col][GameParameters.gameMapSize.row];
		PathFinder.availableBlocks = new boolean[GameParameters.gameMapSize.col][GameParameters.gameMapSize.row];

		/** initialize perlin noise generator */
		noiseGenerator = new PerlinNoiseGenerator(GameParameters.persistence,
				GameParameters.frequency, GameParameters.amplitude,
				GameParameters.octaves, GameParameters.seed);

		/** Process map */
		double height;
		BlockType type = BlockType.PLAIN;
		for (int i = 0; i < GameParameters.gameMapSize.col; i++) {
			for (int j = 0; j < GameParameters.gameMapSize.row; j++) {
				/** Get perlin noise value */
				height = Math.abs(10 + noiseGenerator.get(i, j));
				if (height > 20) {
					height -= 20;
				}
				/** Assign each value to a land type */
				if (0 <= height && height < 5) {
					type = BlockType.WATER;
				} else if (5 <= height && height < 7.5) {
					type = BlockType.JUNGLE;
				} else if (7.5 <= height && height < 14) {
					type = BlockType.PLAIN;
				} else if (14 <= height && height <= 20) {
					type = BlockType.MOUNTAIN;
				}
				/** make land block */
				map[i][j] = new LandBlock(i, j, type, height);
				/** mark blocks as available */
				PathFinder.availableBlocks[i][j] = true;
			}
		}
	}

	public void unlockCells(Coordinates topLeft, Coordinates size) {
		for (int i = 0; i <= size.col; i++) {
			for (int j = 0; j <= size.row; j++) {
				try {
					map[topLeft.col + i][topLeft.row + j].unLock();
					/*if (!(map[topLeft.col + i][topLeft.row + j].getType() == BlockType.PLAIN || thisBlock
							.getType() == BlockType.MOUNTAIN
							&& CourseManager.hasBeenDone("Military"))) { */
						if (map[topLeft.col + i][topLeft.row + j].getType() != BlockType.PLAIN) {
						PathFinder.availableBlocks[topLeft.col + i][topLeft.row
								+ j] = false;
					}
				} catch (Exception e) {
					/**
					 * it's just an array out of bound exception which java'll
					 * take care of ;)
					 */
				}
			}
		}
	}

	public boolean isAvailable(Coordinates topLeft, Coordinates size) {
		try {
			for (int i = 0; i < size.col; i++) {
				for (int j = 0; j < size.row; j++) {
					if (!PathFinder.availableBlocks[topLeft.col + i][topLeft.row
							+ j]) {
						return false;
					}
				}
			}

			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public LandBlock get(Coordinates pos) {
		return map[pos.col][pos.row];
	}
}
